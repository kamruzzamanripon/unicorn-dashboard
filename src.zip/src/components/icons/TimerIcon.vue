<template>
    <svg xmlns="http://www.w3.org/2000/svg" class="mr-4 opacity-50" width="24" height="24" viewBox="0 0 24 24"
        stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <rect x="0" y="0" width="24" height="24" stroke="none"></rect>
        <circle cx="12" cy="12" r="9" />
        <polyline points="12 7 12 12 9 15" />
    </svg>
</template>